package com.custome.customexception.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.custome.customexception.entity.User;
import com.custome.customexception.response.UserResponse;
import com.custome.customexception.service.UserService;

@RestController
@RequestMapping("/api/validation")
public class UserController {
	
	
	@Autowired
	private UserService userService;
	
	
	@GetMapping("/user")
    public UserResponse getValidMobileNum(@RequestBody User mobNum) throws Exception {
		UserResponse response = new UserResponse();
        response = userService.getValidMobileNum(mobNum);
        return response;

    }

	
	@GetMapping("/user/age")
    public UserResponse getValidAge(@RequestBody User age) throws Exception {
		UserResponse response = new UserResponse();
        response = userService.getValidAge(age);
        return response;

    }
	
}
