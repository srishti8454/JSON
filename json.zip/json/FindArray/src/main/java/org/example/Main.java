package org.example;


import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class Main {
    public static void main(String[] args) {

        String[] arr1 = {"ab", "cd", "df", "fg"};
        String[] arr2 = {"cd", "ij", "lo", "fg", "ffg"};
        Set<String> set1 = new HashSet<>(Arrays.asList(arr1));
        Set<String> set2 = new HashSet<>(Arrays.asList(arr2));
        set1.retainAll(set2);
        System.out.println("Most common value(s): " + set1);









    }
}