package com.jsondata.json.service;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jsondata.json.entity.JsonData;
import com.jsondata.json.repository.JsonDataRepository;

@Service
public class JsonDataService {
	
	private final JsonDataRepository jsonDataRepository;
	
	//private final JsonData jsonData;
    private final ObjectMapper objectMapper;

//    @Autowired
    public JsonDataService(JsonDataRepository jsonDataRepository, ObjectMapper objectMapper) {
        this.jsonDataRepository = jsonDataRepository;
        this.objectMapper = objectMapper;
    }

    public void saveJsonData(String jsonString) {
        JsonData jsonData = new JsonData();
        jsonData.setJsonData(jsonString);

        jsonDataRepository.save(jsonData);
    }

}
