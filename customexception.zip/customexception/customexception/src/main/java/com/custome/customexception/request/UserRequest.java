package com.custome.customexception.request;

public class UserRequest {
	
	private int id;
    private String name;
    private String mobNum;
    private int age;
    private String address;
    private String email;
    
    
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobNum() {
		return mobNum;
	}
	public void setMobNum(String mobNum) {
		this.mobNum = mobNum;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public UserRequest(int id, String name, String mobNum, int age, String address, String email) {
		super();
		this.id = id;
		this.name = name;
		this.mobNum = mobNum;
		this.age = age;
		this.address = address;
		this.email = email;
	}
	public UserRequest() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    
    
    
	
    
	
	

}
