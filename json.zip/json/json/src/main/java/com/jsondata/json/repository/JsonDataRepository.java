package com.jsondata.json.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jsondata.json.entity.JsonData;

public interface JsonDataRepository extends JpaRepository<JsonData, Long>{

}
