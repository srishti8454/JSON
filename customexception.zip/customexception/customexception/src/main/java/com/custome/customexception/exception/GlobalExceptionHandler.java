package com.custome.customexception.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.custome.customexception.response.UserResponse;


@ControllerAdvice
public class GlobalExceptionHandler {
	
	
	
	
	@ExceptionHandler(UserDetailsValidation.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<Object> handleUserDetailsValidation(UserDetailsValidation ex) {
        // Customize the response for UserDetailsValidation exception
        UserResponse response = new UserResponse();
        response.setStatusDescription("Validation failed");
        response.setStatusCode("400");
        response.setMessage(ex.getMessage());
        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
    }
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<Object> handleMethodArgsValidation(MethodArgumentNotValidException ex) {
        // Customize the response for UserDetailsValidation exception
        UserResponse response = new UserResponse();
        response.setStatusDescription("Validation failed method args");
        response.setStatusCode("400");
        response.setMessage(ex.getParameter().toString());
        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
    }

	
   

    // Handle other exceptions if needed
//    @ExceptionHandler(Exception.class)
//    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
//    public ResponseEntity<Object> handleOtherExceptions(Exception ex) {
//        // Customize the response for other unexpected exceptions
//        UserResponse response = new UserResponse();
//        response.setStatusDescription("Unexpected error occurred");
//        response.setStatusCode("500");
//        response.setMessage(ex.getMessage());
//        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
//    }

}
