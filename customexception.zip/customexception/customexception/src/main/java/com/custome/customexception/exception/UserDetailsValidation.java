package com.custome.customexception.exception;



public class UserDetailsValidation extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
//	private static final long serialVersionUID = 1L;

	public UserDetailsValidation(String message) {
        super(message);
    }
	
//	 class MobileNotFoundException extends RuntimeException {
//        public MobileNotFoundException(String message) {
//            super(message);
//        }
//    }
//
//    static class EmailNotFoundException extends UserDetailsValidation {
//        public EmailNotFoundException(String message) {
//            super(message);
//        }
//    }
	
	
	

}
