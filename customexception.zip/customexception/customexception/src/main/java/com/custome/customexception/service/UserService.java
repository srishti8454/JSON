package com.custome.customexception.service;



import org.springframework.stereotype.Service;

import com.custome.customexception.entity.User;
import com.custome.customexception.exception.UserDetailsValidation;
import com.custome.customexception.response.UserResponse;



@Service
public class UserService {
	
	
	 public UserResponse getValidMobileNum(User mobNum)  {
		UserResponse  userResponse = new UserResponse();
		
		
//		if (mobNum.getMobNum().length() == 10) {
//			
//			userResponse.setStatusDescription("Mobile number is valid");
//        	userResponse.setStatusCode("101");
//        	userResponse.setMessage("Invalid mobile no");
//			//System.out.println("Mobile no is valid");
//			
//			
//        } else {
//        	
////        	userResponse.setStatusDescription("Mobile no invalid");
////        	userResponse.setStatusCode("404");
////        	userResponse.setMessage("Invalid mobile no");
//        	userResponse.setStatusCode("101");
////            throw new UserDetailsValidation("Invalid mobile no");
//            
//            
//        }
//		
		System.out.println("ghhghjhj something");
	return userResponse;
		
	
	}
	 
	 
	 
	 public UserResponse getValidAge(User age)  {
			UserResponse  userResponse = new UserResponse();
			
			
			if (age.getAge()<20) {
				
				userResponse.setStatusDescription("eglible for marriage");
	        	userResponse.setStatusCode("101");
	        	userResponse.setMessage("eglible for marriage");
				
	        } else {
	        	
	            throw new UserDetailsValidation(" not eglible for marriage");
	            
	            
	        }
			
			return userResponse;
			
		
		}
	 
	 
	 
	
	

}
