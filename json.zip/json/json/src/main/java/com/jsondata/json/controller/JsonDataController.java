package com.jsondata.json.controller;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.jsondata.json.service.JsonDataService;

@RestController
public class JsonDataController {
	
	private final JsonDataService jsonDataService;

    //@Autowired
    public JsonDataController(JsonDataService jsonDataService) {
        this.jsonDataService = jsonDataService;
    }

    @PostMapping("/saveJson")
    public ResponseEntity<String> saveJson(@RequestBody String jsonString) {
        try {
            jsonDataService.saveJsonData(jsonString);
            return new ResponseEntity<>("JSON data saved successfully", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Failed to save JSON data: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    

}
